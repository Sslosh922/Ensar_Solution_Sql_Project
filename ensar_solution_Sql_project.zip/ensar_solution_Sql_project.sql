create table employees (
emp_id int primary key ,
full_name varchar(40),
gender varchar(20),
role varchar(40),
department varchar(40),
salary numeric(20,2),
hike_percentage decimal(5,2),
phone varchar(15),
email varchar(50),
locations varchar(50),
joined_date date,
exit_date date,
status varchar(20)
);

create table interns(
intern_id int  primary key ,
intern_name varchar(40),
domains varchar(40),
assigned_manager bigint,
stipend numeric(20,2),
start_date date,
end_date date
);

create table projects (
project_id int  primary key ,
project_name varchar(40),
project_manager bigint,
start_date date,
end_date date,
budget numeric(20,2),
revenue_generated numeric(20,2)
);

create table project_team(
team_id int primary key,
project_id int ,
emp_id int,
role_in_project varchar(40),
days_required int,

CONSTRAINT abc1

FOREIGN key (project_id)
REFERENCES projects(project_id),

CONSTRAINT abc2
FOREIGN key (emp_id)
REFERENCES employees(emp_id)
);

create table login_logout(
log_id int primary key,
emp_id int,
login_time TIMESTAMP,
logout_time TIMESTAMP,
work_hours numeric(10,2),

CONSTRAINT abc3
FOREIGN key (emp_id)
REFERENCES employees(emp_id)
);

create table assets_issued(
asset_id int primary key,
emp_id int,
asset_description varchar(40),
issue_date date,
expected_return_date date,
actual_return_date date,
received_signature varchar(60),
submission_signature varchar(60),

CONSTRAINT abc4
FOREIGN key (emp_id)
REFERENCES employees(emp_id)
);

--1.Retrieve all active employees from the IT department.

select *from employees limit 20;
select  emp_id,status , department
from  employees
where status = 'Active' and department = 'IT'

--2. List all employees whose salary is greater than ■50,000

select emp_id , salary
from employees
where salary > 50000;

--3.Find all interns assigned to the Data Analytics domain

select intern_id , intern_name,domains
from interns
where domains = 'Data Analytics'

-- 4. Show all projects that started after January 2024.

select project_id, project_name, start_date
from projects
where start_date > '01-01-2024';

select max(start_date) --2023
from projects
-- 5 Display all employees who exited the company in 2024.

select emp_id,full_name,exit_date
from employees 
where extract(year from exit_date) = '2024'

-- 6. Find the total number of employees in each department.

select department,count(emp_id)
from employees
group by department;

--7. Retrieve all employees working on the 'Retail Analytics' project.

select project_name from projects limit 10;
select e1.emp_id , p1.project_name
from projects p1
join project_team p2
on p2.project_id = p1.project_id
join employees e1
on p2.emp_id = e1.emp_id
where project_name = 'Retail Analytics';

-- 8. Count how many interns are assigned under each manager.

select  assigned_manager ,count(intern_id)
from interns
group by assigned_manager 
order by 2 desc;

-- 9. Find the average salary for each role in the company.

select role ,round(avg(salary),2) as avg_salary
from employees 
group by 1
order by 1 desc limit 10;

-- 10 List all employees who have worked more than 9 hours in any day.

select e1.emp_id , full_name , l1.work_hours
from employees e1
join login_logout l1
on l1.emp_id = e1.emp_id
where l1.work_hours > 9;

-- 11.Calculate the total budget allocated to all projects managed by the IT department

select  department ,sum(budget) as total_allocated_budget 
from projects p1 
JOIN employees e1
ON p1.project_manager = e1.emp_id
where department = 'IT'
group by department;

--12. Identify employees who have been issued more than three assets.

select e1.emp_id , full_name, count(asset_id)
from employees e1
join assets_issued a1
on a1.emp_id = e1.emp_id
group by  1, 2 
having count(asset_id) > 3;


-- 13. Retrieve the highest-paid employee from each department.

select  emp_id , full_name ,department,salary
from 
 ( select emp_id, full_name,department,salary,
dense_rank () over (partition by department order by salary desc  ) as rank
from employees
)
where rank =1;

-- 14.List all employees whose salary is higher than the overall company average salary.

select  emp_id , full_name ,salary
from employees
where salary > 
(
select avg(salary)
from employees
);


-- 15 .Find the top 5 employees with the maximum total working hours in the last month.

select  e1.emp_id , full_name ,sum(work_hours)
from employees e1 
join login_logout l1
on e1.emp_id = l1.emp_id
where login_time >= (

 select max(login_time ) -interval '1 month'
 from login_logout
 )
 group by 1, 2
order by sum(work_hours) desc limit 5;

-- 16 .Display employees who are assigned to more than one project.

select e1.emp_id , count(project_id)
from project_team p1
join employees e1
on e1.emp_id = p1.emp_id
group by 1
having count(project_id) > 1

-- 17 Identify employees who joined the company before their reporting manager.

select e1.emp_id, e1.full_name,e1.joined_date, m.emp_id as manager_id,m.joined_date
from employees e1
join project_team p1
on e1.emp_id = p1.emp_id
join projects p2
on p2.project_id = p1.project_id
join employees m
on m.emp_id = p2.project_manager
where e1.joined_date < m.joined_date;

--18.Retrieve employees whose hike percentage is greater than the average hike of their department.

select  emp_id , full_name ,department,hike_percentage
from  employees e1
where hike_percentage > (
select avg(hike_percentage)
from employees e2
 where e2.department = e1.department
)


-- 19 .Rank employees by salary within their role using RANK() or DENSE_RANK().

select  emp_id  ,full_name ,role , salary,ranks
from

( select 
emp_id , full_name,role ,salary,
dense_rank() over(partition by role order by salary desc) as ranks
from employees
)x ;

-- 20 .List employees who have never been issued any asset

select e1.emp_id , full_name, count(asset_id)
from employees e1
left join assets_issued a1
on a1.emp_id = e1.emp_id
group by  1, 2 
having count(asset_id) =0;

-- 21.Determine which project achieved the highest ROI ((revenue − budget) / budget).

select project_id ,  (revenue_generated-budget)/budget as ROI
from projects
order by ROI desc limit 1;


-- 22.Identify employees who logged in late (after 10:00 AM) more than five times within a month.
select  e1.emp_id,full_name,count(l1.emp_id) as late_login_count,
extract(month from l1.login_time) as monthly_login
from employees e1
join login_logout l1
on l1.emp_id = e1.emp_id
where extract (hour from l1.login_time ) > 10
group by  e1.emp_id ,full_name,  extract(month from l1.login_time) 
having count(l1.emp_id) > 5;


-- 23.Calculate total working hours for each employee over the last 30 days.
select e1.emp_id,full_name,sum(work_hours)
from employees e1
join login_logout l1
on l1.emp_id = e1.emp_id
where login_time  >=
(select max(login_time) - interval '30 days'
from login_logout)
group by 1,2

-- 24 .List projects where the total days required by the team exceeded the planned project duration.

select p1.project_id ,start_date, end_date,(end_date-start_date) as project_duration ,sum(days_required)
from projects p1
join project_team p2
on p2.project_id = p1.project_id
group by 1, start_date,end_date
having sum(days_required) > (end_date-start_date)

--25 . Identify employees who exited the company within one year of joining.

select emp_id,full_name,joined_date, exit_Date
from employees
where status = 'Exited' and exit_date <=  joined_date + interval '1 year'

--26 .Calculate the total number of assets that were returned late or never returned.

select count(asset_id) , expected_return_date, actual_return_date
from assets_issued
where  actual_return_date > expected_return_date
or actual_return_date is null
group by 2,3;

--27.List managers who have more than ten employees or interns reporting to them.
select p1.project_manager,count(distinct p2.emp_id) as employee_count
from projects p1
join project_team p2
on p1.project_id = p2.project_id
group by 1
having count(distinct p2.emp_id) > 10;


--28. Retrieve the top three revenue-generating projects along with their team sizes

select p1.project_id,
p1.revenue_generated,
count(p2.emp_id) as team_size
from projects p1
join project_team p2
on p1.project_id = p2.project_id
group by p1.project_id, p1.revenue_generated
order by p1.revenue_generated desc
limit 3;

--29.Compute the number of employees hired in each year (annual hiring trend).

select extract(year from joined_date) as yearly,count(emp_id) as employee_joined
from employees
group by extract(year from joined_date)
order by count(emp_id) desc ;

-- 30 .Identify employees who worked overtime (more than 10 hours in a day).

select e1.emp_id , full_name, work_hours
from employees e1
join login_logout l1
on l1.emp_id = e1.emp_id
where work_hours > 10
group by 1,2,3;

--31. Perform attrition analysis by department

select department,count(emp_id) as employee_exit , count(exit_date) ,
round(count(exit_date)*100.0/count(emp_id),2)
from employees
group by 1
order by round(count(exit_date)*100.0/count(emp_id),2) desc ;

-- 32 .. Find correlation between salary and employee tenure

select corr(
salary,(exit_date - joined_date)) as correlation
from employees
where exit_date is  not  null

-- 33.Compare productivity using total working hours across departments
select e1.department,sum(l1.work_hours) as total_working_hours
from employees e1
join login_logout l1
on l1.emp_id = e1.emp_id
group by 1
order by total_working_hours desc;

-- 34. Analyze asset utilization and late returns.

select  e1.department,count(asset_id),
count( case  when actual_return_date > expected_return_date then 1
end ) late_return_count
from employees e1
join assets_issued a1
on a1.emp_id = e1.emp_id
group by 1

-- 35 .Evaluate project efficiency by comparing planned vs actual timelines.

select  project_name ,(end_date-start_date) as project_duration ,sum(days_required)
from project_team p1
join projects p2
on p2.project_id = p1.project_id
group by  1,2
having (end_date-start_date) < sum(days_required);

-- 36. Determine managerial workload based on team size.
select p1.project_manager,count(distinct p2.emp_id) as team_size
from projects p1
join project_team p2
on p2.project_id = p1.project_id
group by 1
order by team_size desc;

--37.Detect potential ghost logins (duplicate time overlaps)

select  l1.emp_id , l1.login_time , l1.logout_time, l2.login_time, l2.logout_time
from login_logout l1 
join login_logout l2
on l1.emp_id = l2.emp_id
and l1.log_id < l2.log_id
where  l1.login_time < l2.logout_time
and l2.login_time < l1.logout_time

--38. Identify underperforming projects with negative ROI.

select  project_id , (revenue_generated-budget)/budget as ROI
from projects
where  (revenue_generated-budget)/budget < 0

-- 39 . Build a complete employee 360 report using all tables.

select e1.emp_id , e1.full_name , e1.gender  ,e1.salary,
count(distinct p1.project_id ) , sum(work_hours) as working_hours , count(distinct asset_id)
from employees e1
left join project_team p1
on e1.emp_id = p1.emp_id
left join projects p2
on p2.project_id = p1.project_id
left join login_logout l1
on e1.emp_id = l1.emp_id 
left join assets_issued i1
on e1.emp_id = i1.emp_id 
group by 1,2,3,4

-- 40 . Create a full history view joining employees, projects, assets, and attendance.

select e1.emp_id , e1.full_name , e1.gender  ,e1.joined_date,
count(distinct p1.project_id ) , login_time , count(distinct asset_id)
from employees e1
left join project_team p1
on e1.emp_id = p1.emp_id
left join projects p2
on p2.project_id = p1.project_id
left join login_logout l1
on e1.emp_id = l1.emp_id 
left join assets_issued i1
on e1.emp_id = i1.emp_id 
group by 1,2,3,4,6

-- 41 .Build a SQL view showing daily attendance + working hours + project assignment.

select e1.emp_id , e1.full_name , e1.gender  ,e1.joined_date, sum(work_hours) as working_hours,
count(distinct p1.project_id ) , login_time::date
from employees e1
left join project_team p1
on e1.emp_id = p1.emp_id
left join projects p2
on p2.project_id = p1.project_id
left join login_logout l1
on e1.emp_id = l1.emp_id 
group by 1,2,3,4,7

-- 42.Calculate cost per employee per project based on salary share

select e1.emp_id , p2.project_id,e1.salary, (budget/salary) as salary_share
from projects p1
join project_team p2
on p2.project_id = p1.project_id
join employees e1
on e1.emp_id = p2.emp_id
group by 1,2,3,4


-- 43.. Detect employees who have never worked a minimum 8-hour day.

select e1.emp_id , e1.full_name
from employees e1
left join login_logout l2
on l2.emp_id = e1.emp_id
group by 1,2
having max(extract(hours from logout_time - login_time)) <  8 

--44.Identify any assets issued after an employee's exit date.

select asset_id , e1.emp_id,e1.full_name
from employees e1
join assets_issued a1
on e1.emp_id = a1.emp_id
where  exit_date < issue_date  and 
 exit_date is not null  


-- 45 .Find interns who later became full-time employees.

select e1.emp_id , intern_id  , e1.full_name
from interns i1
join employees e1
on e1.emp_id = i1.intern_id
where e1.joined_date > i1.end_date

